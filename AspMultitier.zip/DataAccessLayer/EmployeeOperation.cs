﻿using ModelLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
   public class EmployeeOperation:DbConfig
    {
        public SqlDataReader GetEmployees()
        {
            string query = "select* from employees";
            SqlCommand cmd = new SqlCommand(query, connection);
            if (connection.State == ConnectionState.Closed)
                connection.Open();
           SqlDataReader dr=cmd.ExecuteReader();
            return dr;
 
        }

        public int CreateEmployee(EmployeeModel employee) {

            SqlCommand cmd = new SqlCommand("insert_employee", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", employee.Name);
            cmd.Parameters.AddWithValue("@salary", employee.Salary);
            cmd.Parameters.AddWithValue("@dept", employee.Department);
            cmd.Parameters.AddWithValue("@email", employee.Email);
            cmd.Parameters.AddWithValue("@gender", employee.Gender);
            cmd.Parameters.AddWithValue("@address", employee.Address);
            string org_id="";
                
            cmd.Parameters.Add("@orgid", SqlDbType.VarChar,100);
            cmd.Parameters["@orgid"].Direction = ParameterDirection.Output;
            if (connection.State == ConnectionState.Closed)
                connection.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dr.Read();
            org_id=(string)cmd.Parameters["@orgid"].Value;
            int create = (int)dr[0];

            return create;
        }



        public int DeleteEmployee(int id)
        {
            SqlCommand cmd = new SqlCommand("emp_operation", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@action", 1);
             if (connection.State == ConnectionState.Closed)
                connection.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            dr.Read();
            int i = (int)dr["completed"];          
            return 1;
        }

    }
}
